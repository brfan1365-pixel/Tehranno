تهران نو - پروژه Android
این پروژه نسخه موبایلی بازی را داخل WebView اجرا می‌کند.
برای ساخت APK با Android Studio:
1. پوشه TehranNo را Open کنید.
2. Gradle Sync را انجام دهید.
3. از Build > Build APK(s) استفاده کنید.
فایل خروجی معمولاً در app/build/outputs/apk/debug/app-debug.apk است.
